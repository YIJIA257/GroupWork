#ifndef _COLLISION_LAYER_H_
#define _COLLISION_LAYER_H_

enum class CollisionLayer//��ײ�㼶��ö��
{
	None,
	Player,
	Enemy,
};

#endif
// !_COLLISION_LAYER_H_
