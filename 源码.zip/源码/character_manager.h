#ifndef _CHARACTER_MANAGER_H_
#define _CHARACTER_MANAGER_H_

#include "character.h"

class CharacterManager
{
public:
	static CharacterManager* instance();

	Character* get_enemy()//����ĵõ�ʵ��ָ��ĺ���
	{
		return enemy;
	}

	Character* get_player()
	{
		return player;
	}

	void on_input(const ExMessage& msg);//������Ϣ�Ľ���
	void on_update(float delta);
	void on_render();

private:
	static CharacterManager* manager;

	Character* enemy = nullptr;//ʵ��ָ��
	Character* player = nullptr;

private:
	CharacterManager();
	~CharacterManager();

};

#endif 
// !_CHARACTER_MANAGER_H_
